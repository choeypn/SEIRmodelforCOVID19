# CSCI 474 Project Graphs

library(ggplot2)
library(gtable)
library(gridExtra)
library(RColorBrewer)
setwd("C:/Users/Tyson/OneDrive/Desktop/WWU/2020 Q2 Spring/CSCI 474/Project2-CSCI474/")

# Severe Recovery Period------------------------------------------------------------------------------------
severe_recovery<-read.delim("recovery_severe.txt", header = F, sep=" ")
colnames(severe_recovery)<-c("recovery_days","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                             "hospitalized_date","total_dead","total_recovered","last_date")
counts_sr<-table(severe_recovery)
hist(severe_recovery$hospitalized_date)
table(severe_recovery$hospitalized_date)
hist(table(severe_recovery$hospitalized_date))
ggplot(severe_recovery, aes(y=hospitalized_date, x=recovery_days, fill = max_hospitalized)) +
  geom_tile()
ggplot(severe_recovery, aes(color=hospitalized_date, x=recovery_days, y = max_hospitalized)) +
  geom_point(aes()) +
  scale_color_discrete() +
  labs(y="Hospitalized People", title = "Maximum Number of Hospitalized People versus Length of Severe Case Recovery",
       x="Length of Severe Case Recovery (Days)", color="Date of Maximum Hospitalization") +
  scale_size(guide="none")

  

# Psevere-------------------------------------------------------------------------------------------------------
psevere<-read.delim("psevere.txt", header=F, sep=" ")
colnames(psevere)<-c("psevere","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                             "hospitalized_date","total_dead","total_recovered","last_date")             
ggplot(psevere, aes(color=hospitalized_date, x=psevere, y = max_hospitalized)) +
  geom_point(aes()) +
  labs(y="Hospitalized People", title = "Maximum Number of Hospitalized People versus Probability of a Severe Case",
       x="Probability of a Severe Case", color="Date of Maximum Hospitalization")

# Psevere + Severe Recovery Period
psevere_recovery<-read.delim("psevere2/psevere_recs.txt", header=F, sep=" ")
colnames(psevere_recovery)<-c("psevere", "recovery_days","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                             "hospitalized_date","total_dead","total_recovered","last_date")

ggplot(psevere_recovery, aes(x=psevere, y=recovery_days, color=max_hospitalized, fill=hospitalized_date)) +
  geom_tile()





# Infectious period----------------------------------------------------------------------------------------------
dInf<-read.table("psevere2/infectious_period.txt", header=F, skipNul=T)
dInf$V1[1]=0.04
colnames(dInf)<-c("psevere","days_infectious", "max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                     "hospitalized_date","total_dead","total_recovered","last_date")
ggplot(dInf, aes(x=days_infectious)) +
  geom_point(aes(y=max_infectious, col="Infectious")) +
  geom_point(aes(y=max_exposed, col="Exposed")) +
  geom_point(aes(y=max_hospitalized, col="Hospitalized")) +
  labs(y="Number of People", x="Infectivity period", title="Number of People at Peak versus the infectious period of disease",
       color="Model Output")


# Psevere + cfr-------------------------------------------------------------------------------------------------
psevere_cfr<-read.delim("psevere2/psevere_cfr.txt", header=F, sep=" ")
colnames(psevere_cfr)<-c("cfr","psevere","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                              "hospitalized_date","total_dead","total_recovered","last_date")
cfr1<-ggplot(psevere_cfr, aes(x=cfr, y=psevere, fill=total_dead)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red") +
  labs(x="Case Fatality Rate", y="Psevere", fill="Total Dead", title="Psevere and Case Fatality Rate on the Total Dead and") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size = unit(1, "cm"))
cfr2<-ggplot(psevere_cfr, aes(x=cfr, y=psevere, fill=max_hospitalized)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1,"cm")) +
  labs(x="Case Fatality Rate", y="Psevere", fill="Max in Hospital", title="Maximum Hospitalized")
#  scale_fill_gradient(low="red", high="blue")
grid.arrange(cfr1,cfr2,nrow=1)


# Psevere final----------------------------------------------------------------------------------------------
psevere<-read.delim("psevere.txt",header=F,sep=" ")
colnames(psevere)<-c("psevere","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                     "hospitalized_date","total_dead","total_recovered","last_date") 
ggplot(data=psevere, aes(x=psevere, y=max_hospitalized, color=hospitalized_date)) +
  geom_point()
summary(psevere$max_hospitalized)

# Mild Recovery Period-------------------------------------------------------------------------
recovery_mild<-read.delim("recm.txt",header=F,sep=" ")
colnames(psevere)<-c("recovery_mild","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                     "hospitalized_date","total_dead","total_recovered","last_date") 

# Severe Recovery Period Final---------------------------------------------------------------------------------
recovery_severe<-read.delim("recs.txt",header=F, sep=" ")
colnames(recovery_severe)<-c("recovery_severe","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                     "hospitalized_date","total_dead","total_recovered","last_date") 
ggplot(data=recovery_severe, aes(x=recovery_severe, y=max_hospitalized, color=hospitalized_date)) +
  geom_point()
summary(recovery_severe$max_hospitalized)
model<-lm(max_hospitalized~recovery_severe, data=recovery_severe)
plot((recovery_severe$max_hospitalized)~recovery_severe$recovery_severe)


# Psevere and Recovery Severe-----------------------------------------------
psevere_recs<-read.delim("recovery_severe.txt", header=F, sep=" ")
colnames(psevere_recs)<-c("psevere","recovery_severe","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                             "hospitalized_date","total_dead","total_recovered","last_date") 
recs1<-ggplot(data=psevere_recs, aes(x=recovery_severe, y=psevere, fill=max_hospitalized)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red")+
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1,"cm"))+
  labs(x="Severe Recovery Period (Days)", y="Psevere", fill="Number in Hospital", title="Maximum Number of People in Hospital vs Psevere and Recovery Length")
recs1
getPalette = colorRampPalette(brewer.pal(9, "Set1"))
colorCount = length(unique(psevere_recs$hospitalized_date))
recs2<-ggplot(data=psevere_recs, aes(x=recovery_severe, y=psevere, fill=hospitalized_date)) +
  geom_tile() +
  scale_fill_manual(values=getPalette(colorCount)) +
  labs(x="Severe Recovery Period (Days)", y="Psevere", fill="Date of Peak", title="Date of the Peak of People in Hospital vs Psevere and Recovery Period")
recs2

# r0 + cfr------------------------------------------------------------------
cfr_r0<-read.delim("data/data/cfr_r0.txt",header=F, sep=" ")
colnames(cfr_r0)<-c("R0","cfr","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                          "hospitalized_date","total_dead","total_recovered","last_date")
r01<-ggplot(data=cfr_r0, aes(x=cfr,y=R0,fill=max_hospitalized)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1.25,"cm")) +
  labs(x="Case Fatality Rate", y="R0", fill="Number in Hospital", title="R0 and Case Fatality Rate on the Maximum Hospitalized")
r02<-ggplot(data=cfr_r0, aes(x=cfr,y=R0,fill=total_dead))+
  geom_tile() +
  scale_fill_gradient(low="blue",high="red") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1,"cm")) +
  labs(x="Case Fatality Rate", y="R0", fill="Total Dead", title=" and Total Dead")
grid.arrange(r01,r02,nrow=1)


# cfr + hl--------------------------------------------------------------
cfr_hl<-read.delim("data/data/cfr_hl.txt",header=F, sep=" ")
colnames(cfr_hl)<-c("cfr","hl","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                    "hospitalized_date","total_dead","total_recovered","last_date")
hl1<-ggplot(data=cfr_hl, aes(x=cfr,y=hl,fill=max_hospitalized)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1,"cm")) +
  labs(x="Case Fatality Rate", y="Hospital Lag", fill="Number in Hospital", title="Hospital Lag and Case Fatality Rate on the Maximum Hospitalized")
hl2<-ggplot(data=cfr_hl, aes(x=cfr,y=hl,fill=total_dead))+
  geom_tile() +
  scale_fill_gradient(low="blue",high="red") +
  theme_minimal() +
  theme(legend.position="bottom", legend.key.size=unit(1,"cm")) +
  labs(x="Case Fatality Rate", y="Hospital Lag", fill="Total Dead", title="                and Total Dead")
grid.arrange(hl1,hl2,nrow=1)


# psevere + hl--------------------------------------------------------------
psevere_hl<-read.delim("psevere2/psevere_hl.txt", header=F, sep=" ")
colnames(psevere_hl)<-c("psevere","hl","max_infectious","infectious_date","max_exposed","exposed_date","max_hospitalized",
                    "hospitalized_date","total_dead","total_recovered","last_date")
ggplot(data=psevere_hl, aes(x=hl,y=psevere, fill=max_hospitalized)) +
  geom_tile() +
  scale_fill_gradient(low="blue", high="red")
ggplot(data=psevere_hl, aes(x=hl, y=psevere, fill=hospitalized_date)) +
  geom_tile()
