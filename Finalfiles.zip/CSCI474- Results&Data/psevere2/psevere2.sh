#!/bin/bash

for i in $(seq 0 0.01 0.9)
do
	for j in $(seq 0 1 100)
	do
		python3 ../v3/modelV3_2var.py -psevere $i -i0 $j
	done
done > psevere_i0.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.1 7)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -r0 $j
        done
done > psevere_r0.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.01 0.5)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -cfr $j
        done
done > psevere_cfr.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -hl $j
        done
done > psevere_hl.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -dinc $j
        done
done > psevere_dinc.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -dinf $j
        done
done > psevere_dinf.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.5 40)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -recm $j
        done
done > psevere_recm.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 0.5 40)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -recs $j
        done
done > psevere_recs.txt

for i in $(seq 0 0.01 0.9)
do
        for j in $(seq 0 1 50)
        do
                python3 ../v3/modelV3_2var.py -psevere $i -ttd $j
        done
done > psevere_ttd.txt

