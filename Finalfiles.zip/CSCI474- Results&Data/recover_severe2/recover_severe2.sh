#!/bin/bash

for i in $(seq 0 0.5 40)
do
	for j in $(seq 0 1 100)
	do
		python3 ../v3/modelV3_2var.py -recs $i -i0 $j
	done
done > recs_i0.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.1 7)
        do
                python3 ../v3/modelV3_2var.py -recs $i -r0 $j
        done
done > recs_r0.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.01 0.5)
        do
                python3 ../v3/modelV3_2var.py -recs $i -cfr $j
        done
done > recs_cfr.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -recs $i -hl $j
        done
done > recs_hl.txt

for i in $(seq 0 0.5 20)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -recs $i -dinc $j
        done
done > recs_dinc.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.5 20)
        do
                python3 ../v3/modelV3_2var.py -recs $i -dinf $j
        done
done > recs_dinf.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.01 0.9)
        do
                python3 ../v3/modelV3_2var.py -psevere $j -recs $i
        done
done > recs_psevere.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 0.5 40)
        do
                python3 ../v3/modelV3_2var.py -recs $i -recm $j
        done
done > recs_recm.txt

for i in $(seq 0 0.5 40)
do
        for j in $(seq 0 1 50)
        do
                python3 ../v3/modelV3_2var.py -recs $i -ttd $j
        done
done > recs_ttd.txt

